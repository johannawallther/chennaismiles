WELCOME TO WEBFORM CIVICRM!

GETTING STARTED

- Download and enable this module, plus CiviCRM, Webform, and Libraries.
- Create a new webform (or go to edit an existing one).
- Click on the CiviCRM tab.
- Enable the fields you like, and optionally choose introduction text and other settings.
- Customize the webform settings for your new fields however you wish.

Further instructions can be found at:
http://wiki.civicrm.org/confluence/display/CRMDOC/Webform+CiviCRM+Integration
