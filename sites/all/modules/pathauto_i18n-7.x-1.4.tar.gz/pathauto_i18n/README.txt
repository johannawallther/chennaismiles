README.txt
==========

This module provides functionality to create aliases for each language.

USAGE:
==========
Set up and use:
1) Install and activate the module.
2) Enable multilingual support for nodes(needs only for nodes)
3) Configure alias patterns on page admin/config/search/path/patterns
4) Create entity with option "Generate automatic URL alias for other languages"
